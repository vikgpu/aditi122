//
//  ViewController.swift
//  NewsDemo
//
//  Created by Vikas Gupta on 30/09/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import UIKit
import SDWebImage
import Foundation

class ViewController: UIViewController,UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        if(searchhis == "No"){
            
            return self.sourceListViewModel.sourceViewModels.count
            
        }else{
            
            return self.searchArraArray.count
        }
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewsTableViewCell", for: indexPath) as! NewsTableViewCell
        cell.backgroundColor = UIColor.clear
        
        cell.bgView.frame = CGRect(x: 10, y: 10, width: self.view.frame.size.width-20, height: 240)
        cell.bgView.layer.shadowColor = UIColor.lightGray.cgColor
        cell.bgView.layer.shadowOffset = CGSize(width: 0.5, height: 0.4)
        cell.bgView.layer.shadowOpacity = 0.4
        cell.bgView.layer.shadowRadius = 10.0 //Here your control your blur
        cell.bgView.layer.masksToBounds = false
        cell.bgView.layer.cornerRadius = 5.0
        cell.bgView.backgroundColor = UIColor.white
        cell.addSubview(cell.bgView)
        
        cell.displayImage.frame = CGRect(x: 0, y: 0, width: cell.bgView.frame.size.width, height: 150)
        
        
        cell.bgView.addSubview(cell.displayImage)
        
        
        
        
        
         if(searchhis == "No"){
            
            let newsdata =  self.sourceListViewModel.sourceViewModels[indexPath.row]
            
            cell.displayImage.sd_setImage(with: URL(string: newsdata.urlToImage), placeholderImage: UIImage(named: "placeholder.png"))
            
            cell.titleLbl.frame = CGRect(x: 5, y: cell.displayImage.frame.origin.y+cell.displayImage.frame.size.height+10, width: cell.frame.size.width-30, height: 20)
            cell.titleLbl.textColor = UIColor.black
            cell.titleLbl.font = UIFont.boldSystemFont(ofSize: 14.0)
            cell.titleLbl.text = newsdata.title
            cell.titleLbl.numberOfLines = 0
            cell.titleLbl.sizeToFit()
            cell.bgView.addSubview(cell.titleLbl)
            
            
            
            cell.timeLbl.frame = CGRect(x:cell.frame.size.width-195, y:cell.titleLbl.frame.origin.y+cell.titleLbl.frame.size.height + 10, width: 165, height:15)
            cell.timeLbl.textColor = UIColor(red: 45.0/255.0, green: 45.0/255.0, blue: 45.0/255.0, alpha: 1.0)
            cell.timeLbl.text = newsdata.publishedAt
            cell.timeLbl.numberOfLines = 0
            cell.timeLbl.font = UIFont.systemFont(ofSize: 15.0)
            cell.bgView.addSubview(cell.timeLbl)
            
            
         }else{
            
            let newsdata = (self.searchArraArray[indexPath.row]) as! SourceViewModel
 
            cell.displayImage.sd_setImage(with: URL(string: newsdata.urlToImage), placeholderImage: UIImage(named: "placeholder.png"))
            
            cell.titleLbl.frame = CGRect(x: 5, y: cell.displayImage.frame.origin.y+cell.displayImage.frame.size.height+10, width: cell.frame.size.width-30, height: 20)
            cell.titleLbl.textColor = UIColor.black
            cell.titleLbl.font = UIFont.boldSystemFont(ofSize: 14.0)
            cell.titleLbl.text = newsdata.title
            cell.titleLbl.numberOfLines = 0
            cell.titleLbl.sizeToFit()
            cell.bgView.addSubview(cell.titleLbl)
            
            
            
            cell.timeLbl.frame = CGRect(x:cell.frame.size.width-195, y:cell.titleLbl.frame.origin.y+cell.titleLbl.frame.size.height + 10, width: 165, height:15)
            cell.timeLbl.textColor = UIColor(red: 45.0/255.0, green: 45.0/255.0, blue: 45.0/255.0, alpha: 1.0)
            cell.timeLbl.text = newsdata.publishedAt
            cell.timeLbl.numberOfLines = 0
            cell.timeLbl.font = UIFont.systemFont(ofSize: 15.0)
            cell.bgView.addSubview(cell.timeLbl)
        }
        
        cell.selectionStyle = .none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 260
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if(searchhis == "No"){
            
            let newsdata =  self.sourceListViewModel.sourceViewModels[indexPath.row]
            
            let mapViewControllerObj = storyboard?.instantiateViewController(withIdentifier: "NewsDetailViewController") as? NewsDetailViewController
            mapViewControllerObj?.urlString = newsdata.url
            self.present(mapViewControllerObj!, animated: false, completion: nil)
            
        }else{
            
            let newsdata = (self.searchArraArray[indexPath.row]) as! SourceViewModel
            
            let mapViewControllerObj = storyboard?.instantiateViewController(withIdentifier: "NewsDetailViewController") as? NewsDetailViewController
            mapViewControllerObj?.urlString = newsdata.url
            self.present(mapViewControllerObj!, animated: false, completion: nil)
            
        }
        
        
        
    }
   
    
    @IBOutlet weak var navigationTitle: UILabel!
    @IBOutlet weak var backButton: UIButton!
    
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    var scrollView: UIScrollView!
    @IBOutlet weak var navigationView: UIView!
    var lineView: UIView!
    private var webservice :Services!
    private var sourceListViewModel :SourceListViewModel!
    var searchArraArray = NSMutableArray()
    var searchhis = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        textField.delegate = self
        
        searchhis = "No"
        
        navigationView.backgroundColor = Colors.navigationColor()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .none
        tableView.separatorStyle = .none
        
        scrollView = UIScrollView(frame:CGRect(x: 0, y: navigationView.frame.origin.y+navigationView.frame.size.height, width: self.view.frame.size.width, height: 40))
        scrollView.backgroundColor = Colors.navigationColor()
        scrollView.bounces = false
        scrollView.delegate = self
        scrollView.showsHorizontalScrollIndicator = false
        view.addSubview(scrollView)
        
        let lineview = UIView(frame: CGRect(x: 0, y: scrollView.frame.size.height-1, width: self.view.frame.size.width, height: 1))
        lineview.backgroundColor = UIColor(red: 232.0/255.0, green: 232.0/255.0, blue: 232.0/255.0, alpha: 1.0)
        scrollView.addSubview(lineview)
        
        lineView = UIView()
        lineView.backgroundColor = UIColor.white
        scrollView.addSubview(lineView)
        
        var firstNames = ["Recent", "Business", "TechCrunch","6 months"]
        
        var dx: CGFloat = 10
        
        // var dx:NSInteger
        
        for i in 0..<firstNames.count
        {
            
            
            
            let allButton = UIButton(frame:CGRect(x: dx, y:0, width: self.view.frame.size.width/4, height: 38))
            
            allButton.setTitle(firstNames[i], for: .normal)
            allButton.titleColor( for: .normal)
            allButton.setTitleColor(Colors.buttonTextunSelectedColor(), for: .normal)
            allButton.titleLabel?.font = UIFont.systemFont(ofSize: 13.0)
            allButton.tag = 100+i;
            //newsButton.sizeToFit()
            allButton.addTarget(self, action: #selector(ButtonAction(_:)), for: .touchUpInside)
            scrollView.addSubview(allButton)
            // CGFloat float =
            dx+=(allButton.frame.size.width + 5)
            
            if(i == 0)
            {
                
                lineView.frame = CGRect(x: 0, y:38, width: (allButton.frame.size.width)+10, height: 2)
                allButton.setTitleColor(Colors.buttonTextSelectedColor(), for: .normal)
                
            }
            else
            {
                allButton.setTitleColor(Colors.buttonTextunSelectedColor(), for: .normal)
                
            }
            
        }
        
        lineview.frame = CGRect(x: 0, y: scrollView.frame.size.height-1, width: dx, height: 1)
        scrollView.contentSize = CGSize(width: dx, height: 0)
        
        updateUI()
    }
    
    @objc func ButtonAction(_ button: UIButton)
    {
       
        
        let recentButton = view.viewWithTag(100) as? UIButton
        let businessButton = view.viewWithTag(101) as? UIButton
        let techButton = view.viewWithTag(102) as? UIButton
        let monthButton = view.viewWithTag(103) as? UIButton
        
        if(button.tag == 100)
        {
            for i in 0..<4
            {
                let allbutton = self.view.viewWithTag(100+i) as? UIButton
                if(button.tag == 100+i)
                {
                    allbutton?.setTitleColor(Colors.buttonTextSelectedColor(), for: .normal)
                    self.lineView.frame = CGRect(x: 0, y:38, width:(allbutton?.frame.size.width)! , height: 2)
                     
                    
                }else{
                    
                    allbutton?.setTitleColor(Colors.buttonTextunSelectedColor(), for: .normal)
                    
                }
            }
        }
        if(button.tag == 101)
        {
            for i in 0..<4
            {
                let allbutton = self.view.viewWithTag(100+i) as? UIButton
                if(button.tag == 100+i)
                {
                    allbutton?.setTitleColor(Colors.buttonTextSelectedColor(), for: .normal)
                    self.lineView.frame = CGRect(x: (recentButton?.frame.origin.x)!+(recentButton?.frame.size.width)!, y:38, width:(allbutton?.frame.size.width)! , height: 2)
                    
                    
                }else{
                    
                    allbutton?.setTitleColor(Colors.buttonTextunSelectedColor(), for: .normal)
                    
                }
            }
        }
        if(button.tag == 102)
        {
            for i in 0..<4
            {
                let allbutton = self.view.viewWithTag(100+i) as? UIButton
                if(button.tag == 100+i)
                {
                    allbutton?.setTitleColor(Colors.buttonTextSelectedColor(), for: .normal)
                    self.lineView.frame = CGRect(x: (businessButton?.frame.origin.x)!+(businessButton?.frame.size.width)!, y:38, width:(allbutton?.frame.size.width)! , height: 2)
                    
                    
                }else{
                    
                    allbutton?.setTitleColor(Colors.buttonTextunSelectedColor(), for: .normal)
                    
                }
            }
        }
        if(button.tag == 103)
        {
            for i in 0..<4
            {
                let allbutton = self.view.viewWithTag(100+i) as? UIButton
                if(button.tag == 100+i)
                {
                    allbutton?.setTitleColor(UIColor.white, for: .normal)
                    self.lineView.frame = CGRect(x: (techButton?.frame.origin.x)!+(techButton?.frame.size.width)!, y:38, width:(allbutton?.frame.size.width)! , height: 2)
                    
                    
                }else{
                    
                    allbutton?.setTitleColor(UIColor.lightGray, for: .normal)
                    
                    
                }
            }
        }
        
    }
    
    @IBAction func searchButtonAction(_ sender: Any) {
        
        searchButton.isHidden = true
        backButton.isHidden = false
        textField.isHidden = false
        navigationTitle.isHidden = true
        textField.becomeFirstResponder()
    }
    
    @IBAction func hidetextField(_ sender: Any) {
        
        searchButton.isHidden = false
        backButton.isHidden = true
        textField.isHidden = true
         navigationTitle.isHidden = false
        searchArraArray.removeAllObjects()
        searchhis = "No"
        tableView.reloadData()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        
     
        
        
        var search:String!
        
        search = textField.text!+string
        
        if(search.count == 1)
        {
            if(string == "")
            {
                search = ""
            }
            
        }
        
        if search.isEmpty
        {
           searchArraArray.removeAllObjects()
            searchhis = "No"
            tableView.reloadData()
        }else{
            
            searchArraArray.removeAllObjects()
 
            for dic in self.sourceListViewModel.sourceViewModels {
                
                
                if(dic.title.lowercased().contains(search)){
                
                    searchArraArray.add(dic)

                }

            if searchArraArray.count > 0
            {
                searchhis = "Yes"
                tableView.reloadData()
            }
            
        }


        }
    
         return true
    }
    private func updateUI() {
        
        
        self.webservice = Services()
        self.sourceListViewModel = SourceListViewModel(Services: self.webservice)
        self.sourceListViewModel.bindToSourceViewModels = {
            print("\(self.sourceListViewModel.sourceViewModels.count)")
            self.tableView.reloadData()
        }
        
    }

}

