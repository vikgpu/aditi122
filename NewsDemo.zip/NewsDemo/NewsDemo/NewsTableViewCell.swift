//
//  NewsTableViewCell.swift
//  invisionapp
//
//  Created by SR Infosystem on 10/10/18.
//  Copyright © 2018 Vikas Gupta. All rights reserved.
//

import UIKit

class NewsTableViewCell: UITableViewCell {

    let bgView = UIView()
    let titleLbl = UILabel()
    let descriptionLbl = UILabel()
    let timeLbl = UILabel()
   let displayImage = UIImageView()
    override func awakeFromNib() {
        super.awakeFromNib()
        
        addSubview(bgView)
        bgView.addSubview(titleLbl)
        bgView.addSubview(descriptionLbl)
        bgView.addSubview(timeLbl)
        bgView.addSubview(displayImage)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
