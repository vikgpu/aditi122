//
//  Webservice.swift
//  Headlines
//
//  Created by Mohammad Azam on 11/19/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import Foundation

typealias JSONDictionary = [String:Any]

class Services {
    
    private let sourcesURL = URL(string: "https://newsapi.org/v2/everything?q=bitcoin&from=2019-09-05&sortBy=publishedAt&apiKey=6f8d2a728e554c81a20960fa3b1a1a9e")!
    
    
    func loadSources(completion :@escaping ([Source]) -> ()) {
        
        URLSession.shared.dataTask(with: sourcesURL) { data, _, _ in
            
            if let data = data {
                
           //     let json = try! JSONSerialization.jsonObject(with: data, options: [])
                
                let dataDict: [String: Any] = try! JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as! [String: Any]
                print(dataDict)
                
                if(((dataDict["status"]) as! String) == "ok")
                {
                    let sourceDictionary = (dataDict["articles"]) as! [JSONDictionary]
                    let sources = sourceDictionary.flatMap(Source.init)
                    DispatchQueue.main.async {
                        completion(sources)
                    }
                }
                
                
               
            }
            
            }.resume()
        
    }
    
}
