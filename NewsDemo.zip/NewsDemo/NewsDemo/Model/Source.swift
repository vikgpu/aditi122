//
//  Source.swift
//  Headlines
//
//  Created by Mohammad Azam on 11/19/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import Foundation

class Source {
    
    var author :String!
    var title :String!
    var description :String!
    var url :String!
    var urlToImage :String!
    var publishedAt :String!
    var content :String!
    
    init?(dictionary :JSONDictionary) {
        
        guard let author = dictionary["author"] as? String,
        let title = dictionary["title"] as? String,
        let description = dictionary["description"] as? String,
        let url = dictionary["url"] as? String,
        let urlToImage = dictionary["urlToImage"] as? String,
        let publishedAt = dictionary["publishedAt"] as? String,
        let content = dictionary["content"] as? String else {
                return nil
    }
        
        self.author = author
        self.title = title
        self.description = description
         self.url = url
         self.urlToImage = urlToImage
         self.publishedAt = publishedAt
         self.content = content
}
    
    init(viewModel :SourceViewModel) {
        
        self.author = viewModel.author
        self.title = viewModel.title
        self.description = viewModel.desc
        self.url = viewModel.url
        self.urlToImage = viewModel.urlToImage
        self.publishedAt = viewModel.publishedAt
        self.content = viewModel.content
    }
    
}
