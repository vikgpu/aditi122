//
//  Colors.swift
//  Car Racing Challenge
//
//  Created by Alex Ongarato on 4/28/15.
//  Copyright (c) 2015 Alex Ongarato. All rights reserved.
//

import Foundation
import UIKit
class Colors
{
    
    static func backgraoundColor() -> UIColor
    {
        return UIColor(red: 248.0 / 255.0, green: 248.0 / 255.0, blue: 248.0 / 255.0, alpha: 1.0);
        
    }
    static func navigationColor() -> UIColor
    {
        return UIColor(red: 0.0/255.0, green: 87.0/255.0, blue: 162.0/255.0, alpha: 1.0);
    }
    static func buttonTextSelectedColor() -> UIColor
    {
        return UIColor.white;
    }
    static func buttonTextunSelectedColor() -> UIColor
    {
        return UIColor.lightGray;
    }
    

}

