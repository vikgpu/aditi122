//
//  Constants.swift
//  Headlines
//
//  Created by Mohammad Azam on 11/20/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import Foundation
import UIKit

struct Maximum {
    static let allowedCharactersForDescription = 70 
}



struct Cells {
    
    static let source = "NewsTableViewCell"
    
}
struct ActivityIndicator {
    
    let indicatorBackView = UIView()
    let view: UIView
    let activityIndicator = UIActivityIndicatorView()
    let loadingTextLabel = UILabel()
    let containerView = UIView()
    
    func showActivityIndicator() {
        
        indicatorBackView.frame = CGRect(x: 0.0, y: 0.0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        indicatorBackView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.addSubview(indicatorBackView)
        
        containerView.frame = CGRect(x: 0.0, y: 0.0, width: 150, height: 100)
        containerView.center = view.center
        containerView.backgroundColor = UIColor.init(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 1.0)
        indicatorBackView.addSubview(containerView)
        containerView.layer.cornerRadius = 5
        
        activityIndicator.frame = CGRect(x: 0.0, y: 15, width: containerView.frame.size.width, height: 45)
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = .gray
        activityIndicator.color = .white
        activityIndicator.startAnimating()
        containerView.addSubview(activityIndicator)
        
        loadingTextLabel.textColor = UIColor.white
        loadingTextLabel.text = "Please Wait..."
        loadingTextLabel.font = UIFont.systemFont(ofSize: 15)
        loadingTextLabel.sizeToFit()
        loadingTextLabel.frame = CGRect(x: 0.0, y: activityIndicator.frame.origin.y+activityIndicator.frame.size.height, width: containerView.frame.size.width, height: 20)
        loadingTextLabel.textAlignment = .center
        containerView.addSubview(loadingTextLabel)
        
    }
    
    func stopActivityIndicator() {
        indicatorBackView.removeFromSuperview()
        activityIndicator.stopAnimating()
        activityIndicator.removeFromSuperview()
    }
}

extension UIImage {
    convenience init?(url: URL?) {
        guard let url = url else { return nil }
        
        do {
            let data = try Data(contentsOf: url)
            self.init(data: data)
        } catch {
            print("Cannot load image from url: \(url) with error: \(error)")
            return nil
        }
    }
}
extension String {
    func heightWithConstrainedWidth(width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [NSAttributedString.Key.font: font], context: nil)
        return boundingBox.height
    }
}
extension UITextField
{
    func paddingMethord()  {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: self.frame.height))
        self.leftViewMode = .always
        self.leftView = paddingView
    }
}

