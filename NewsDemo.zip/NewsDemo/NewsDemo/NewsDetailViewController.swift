//
//  NewsDetailViewController.swift
//  NewsDemo
//
//  Created by Vikas Gupta on 03/10/19.
//  Copyright © 2019 Vikas Gupta. All rights reserved.
//

import UIKit

class NewsDetailViewController: UIViewController,UIWebViewDelegate {

    var  activityIndicator : ActivityIndicator?
    var urlString = String()
    @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let url = URL(string: urlString)
        //  let url = Bundle.main.url(forResource: replaced, withExtension: "pdf")
        let urlRequest = URLRequest(url: url!)
        webView.loadRequest(urlRequest)
        webView.delegate = self
        webView.scrollView.bounces = false
        
        activityIndicator = ActivityIndicator(view: view)
        activityIndicator?.showActivityIndicator()
        
    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        // self.activityIndicator?.stopActivityIndicator()
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error)
    {
        self.activityIndicator?.stopActivityIndicator()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        self.activityIndicator?.stopActivityIndicator()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        
        self.dismiss(animated: false, completion: nil)
    }
    
    

}
