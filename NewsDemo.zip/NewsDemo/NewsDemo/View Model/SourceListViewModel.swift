//
//  SourceListViewModel.swift
//  Headlines
//
//  Created by Mohammad Azam on 11/19/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import Foundation

class SourceListViewModel : NSObject {
    
    @objc dynamic private(set) var sourceViewModels :[SourceViewModel] = [SourceViewModel]()
    private var token :NSKeyValueObservation?
    var bindToSourceViewModels :(() -> ()) = {  }
    private var Services :Services
    
    init(Services :Services) {
        
        self.Services = Services
        super.init()
        
        token = self.observe(\.sourceViewModels) { _,_ in
            self.bindToSourceViewModels()
        }
        
        // call populate sources
        populateSources()
    }
    
    func invalidateObservers() {
        self.token?.invalidate()
    }
    
    func populateSources() {
        
        self.Services.loadSources { [unowned self] sources in
            self.sourceViewModels = sources.flatMap(SourceViewModel.init)
        }
    }
    
    func addSource(source: SourceViewModel) {
        self.sourceViewModels.append(source)
    }
    
    func source(at index:Int) -> SourceViewModel {
        return self.sourceViewModels[index]
    }
    
    
}

class SourceViewModel : NSObject {
    
    var author :String!
    var title :String!
    var desc :String!
   // var description:String!
    var url :String!
    var urlToImage :String!
    var publishedAt :String!
    var content :String!
    
    init(author :String, title: String, desc: String,url :String,urlToImage :String,publishedAt :String,content :String) {
        self.author = author
        self.title = title
        self.desc = desc
        self.url = url
        self.urlToImage = urlToImage
        self.publishedAt = publishedAt
        self.content = content
    }
    
    init(source :Source) {
        
        self.author = source.author
        self.title = source.title
        self.desc = source.description
        self.url = source.url
        self.urlToImage = source.urlToImage
        self.publishedAt = source.publishedAt
        self.content = source.content
    }
}



